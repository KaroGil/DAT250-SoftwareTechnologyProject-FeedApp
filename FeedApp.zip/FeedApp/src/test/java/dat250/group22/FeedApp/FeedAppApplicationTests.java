package dat250.group22.FeedApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
