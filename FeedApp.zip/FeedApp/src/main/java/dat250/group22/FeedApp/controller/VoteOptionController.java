package dat250.group22.FeedApp.controller;

public class VoteOptionController {
    
}
